YES WE CAN SUCCEED PHYSICS ACADEMY — MANUAL PAYMENT STARTER

Instructor: Eng. Ngasi Pelvic
Temporary MTN MoMo recipient: OWAMBA NGASI
MTN number: 671467302

This version is intended as a free starter/prototype.
Students can:
- view courses
- see manual MTN payment instructions
- register
- submit amount and transaction/reference number

IMPORTANT:
This starter does NOT send money, verify transactions automatically, or provide real secure online accounts.
The submitted registration is stored only in the browser's local storage.
For a production academy, we will add a secure server/database, proper authentication, teacher dashboard, and later automatic MTN payment integration.

Never publish or share your MoMo PIN, password, OTP, secret keys, or other private credentials.
