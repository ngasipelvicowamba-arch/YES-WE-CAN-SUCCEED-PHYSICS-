function choose(course){
 document.getElementById("course").value=course;
 document.getElementById("payment").scrollIntoView({behavior:"smooth"});
}
function register(e){
 e.preventDefault();
 const data={
  name:document.getElementById("name").value,
  phone:document.getElementById("phone").value,
  email:document.getElementById("email").value,
  level:document.getElementById("level").value,
  course:document.getElementById("course").value,
  amount:document.getElementById("amount").value,
  reference:document.getElementById("reference").value
 };
 localStorage.setItem("ywcs_registration",JSON.stringify(data));
 document.getElementById("msg").textContent="Registration submitted. Payment is pending manual verification by Eng. Ngasi Pelvic.";
 document.getElementById("msg").style.fontWeight="700";
}
